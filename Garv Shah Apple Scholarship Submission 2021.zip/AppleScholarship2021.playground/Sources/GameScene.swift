
import SpriteKit

public class GameScene: SKScene, SKPhysicsContactDelegate {
    var ball: SKShapeNode!
    var rows: CGFloat!
    var pegs = [SKShapeNode]()
    var baskets = [SKLabelNode]()
    var nums = [IntegerLiteralType]()
    var basket: SKLabelNode!
    
    public override func didMove(to view: SKView) {
        rows = 9.0
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0.0
        physicsWorld.contactDelegate = self
        
        
            // Background
        let bg = SKSpriteNode(color: .systemGray, size: CGSize(width: frame.width, height: frame.height))
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
            // Main Ball
        createMainBall()
        
            //Pegs
        /*
         This loop is extremely inefficient, with a time complexity of O(n^2). To fix later, by finding a formula which can determine the x and y coordinates based on the index of the peg instead of calculating the coordinates spacially as such
         */
        for yVal in stride(from: 2, through: Int(rows + 1), by: 1) {
            for xVal in stride(from: 0, through: yVal - 2, by: 1) {
                let currentX = frame.midX + 2*(CGFloat((CGFloat(xVal) * frame.height/CGFloat(rows + 3)))) - 2*((frame.height/CGFloat(rows + 3) * CGFloat(yVal))/2) + 2*(frame.height/CGFloat(rows + 3))  //mcalculates x position of peg
                let currentY = frame.height - (frame.height/CGFloat(rows + 3)) * CGFloat(yVal)  // calculates y position of peg
                createPeg(pegX: currentX, pegY: currentY)
            }
        }
        
        //Bottom Baskets
            for xVal in stride(from: -1, through: rows - 1, by: 1) {
                let currentX = frame.midX + 2*(CGFloat((CGFloat(xVal) * frame.height/CGFloat(rows + 3)))) - 2*((frame.height/CGFloat(rows + 3) * CGFloat(rows + 1))/2) + 2*(frame.height/CGFloat(rows + 3))  //mcalculates x position of peg
                basket = SKLabelNode()
                nums.append(0)
                basket.text = "\(Int(CGFloat(nums[Int(xVal) + 1])))"
                basket.fontSize = 60
                basket.fontColor = .white
                basket.position = CGPoint(x: currentX + (frame.width/(rows + 1))/2, y: 32)
                addChild(basket)
                baskets.append(basket)
                basket.physicsBody = SKPhysicsBody(circleOfRadius: frame.height * 0.08)
                basket.physicsBody?.isDynamic = false
                basket.physicsBody?.affectedByGravity = false
                basket.physicsBody?.categoryBitMask = Bitmasks.basket
                basket.physicsBody?.contactTestBitMask = Bitmasks.ball
            }
    }
    
    func createPeg(pegX: CGFloat, pegY: CGFloat) {
        let peg = SKShapeNode(circleOfRadius: frame.width * 0.01)
        peg.position = CGPoint(x: pegX, y: pegY)
        peg.strokeColor = .white
        peg.fillColor = .white
        addChild(peg)
        pegs.append(peg)
        
        peg.physicsBody = SKPhysicsBody(circleOfRadius: frame.width * 0.01)
        peg.physicsBody?.isDynamic = false
        peg.physicsBody?.categoryBitMask = Bitmasks.peg
        peg.physicsBody?.contactTestBitMask = Bitmasks.ball
    }
    
    func createMainBall() {
        ball = SKShapeNode(circleOfRadius: 0.32*(frame.height/CGFloat(rows + 3)))
        ball.position = CGPoint(x: frame.midX, y: frame.height - (frame.height/CGFloat(rows + 2)) * 1.0)
        ball.strokeColor = .black
        ball.fillColor = .black
        ball.name = "ball"
        addChild(ball)
        
        ball.physicsBody = SKPhysicsBody(circleOfRadius: 0.32*(frame.height/CGFloat(rows + 3)))
        ball.physicsBody?.isDynamic = true
        ball.physicsBody?.categoryBitMask = Bitmasks.ball
        ball.physicsBody?.contactTestBitMask = Bitmasks.peg
        ball.physicsBody?.applyImpulse(CGVector(dx: CGFloat(Double(arc4random_uniform(5)) - 2.5), dy: 0.0))  // Makes it so the ball doesn't just sit on the top peg but instead moves a slight bit in a random direction so it falls
        ball.physicsBody?.density = 0.2
        ball.physicsBody?.friction = 0.3
        ball.physicsBody?.restitution = 0.28
    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.categoryBitMask == Bitmasks.ball && contact.bodyB.categoryBitMask == Bitmasks.basket {
            upVal(num: contact.bodyB.node as! SKLabelNode)
            restart()
        } else if contact.bodyB.categoryBitMask == Bitmasks.ball && contact.bodyA.categoryBitMask == Bitmasks.basket{
            upVal(num: contact.bodyA.node as! SKLabelNode)
            restart()
        }
    }
    
    func upVal (num: SKLabelNode) {
        nums[baskets.firstIndex(of: num)!] += 1
        num.text = "\(nums[baskets.firstIndex(of: num)!])"
    }
    
    func restart () {
        for child in self.children {
            if child.name == "ball" {
                child.removeFromParent()
            }
        }
        createMainBall()
    }
}
