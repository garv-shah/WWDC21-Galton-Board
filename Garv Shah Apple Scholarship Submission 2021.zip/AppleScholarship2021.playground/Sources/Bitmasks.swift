public struct Bitmasks {
    static let ball: UInt32 = 1 << 1
    static let peg: UInt32 = 1 << 2
    static let basket: UInt32 = 1 << 3
}
